--[]
insert into t (name) values ('Donald Duck'); 
insert into t (name) values ('Mickey Mouse');
insert into t (name) values ('Marvin the Martian');
--[/]
--[]
insert into t (name) values ('Woody Pride'); 
insert into t (name) values ('Buzz Lightyear');
insert into t (name) values ('Jessica Jane Pride');
--[/]

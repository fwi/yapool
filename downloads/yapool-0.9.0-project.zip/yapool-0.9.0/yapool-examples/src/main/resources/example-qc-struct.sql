--[]
create table t 
(id integer generated always as identity(start with 100) primary key, 
name varchar(256));
--[/]

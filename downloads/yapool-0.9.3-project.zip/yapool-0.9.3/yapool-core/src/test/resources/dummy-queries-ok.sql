--[DUMMY1]
select dummy1
--[/DUMMY1]
--[DUMMY2]
select dummy2
--[/DUMMY2]
--[DUMMY3]
select dummy3
--[/DUMMY3]

--[DUMMY1]
select dummy1
--[DUMMY2]
select dummy2
--[DUMMY3]
select dummy3
--[DUMMY4]
-- Shows warning for an empty query
--[DUMMY5]
-- Also Shows warning for an empty query
--[DUMMY6]
select dummy6